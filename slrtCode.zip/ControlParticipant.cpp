/**
 * @file ControlParticipant.cpp
 * ControlParticipant definitions
 *
 * Copyright 2019 The MathWorks, Inc.
 */

#include "fastrtps/fastrtps_all.h"
#include "fastrtps/utils/IPLocator.h"
#include "include/ControlParticipant.h"

using namespace eprosima::fastrtps;
using namespace eprosima::fastrtps::rtps;
using namespace slrealtime::rtps;

ControlParticipant::ControlParticipant(){
}

bool ControlParticipant::init(
    const std::string& targetAddress)
{

    //CREATE THE PARTICIPANT
    ParticipantAttributes PParam;
    PParam.rtps.builtin.domainId = SLRT_DOMAIN_ID;
    PParam.rtps.setName("ControlParticipant");

    Locator_t initialPeer, default_unicast;

    IPLocator::setIPv4(initialPeer, targetAddress);
    initialPeer.port = TARGET_PORT_SLRTD;
    PParam.rtps.builtin.initialPeersList.push_back(initialPeer);
    initialPeer.port = TARGET_PORT_MODEL;
    PParam.rtps.builtin.initialPeersList.push_back(initialPeer);
    initialPeer.port = TARGET_PORT_LOGD;
    PParam.rtps.builtin.initialPeersList.push_back(initialPeer);

    default_unicast.port = HOST_PORT_DEVICE;
    PParam.rtps.builtin.metatrafficUnicastLocatorList.push_back(default_unicast);

    PParam.rtps.builtin.leaseDuration_announcementperiod.seconds = 1;
    PParam.rtps.builtin.leaseDuration.seconds = 2;

    PParam.rtps.port.portBase = HOST_PORT_BASE;

    Locator_t default_meta_unicast_locator;
    PParam.rtps.builtin.metatrafficUnicastLocatorList.push_back(default_meta_unicast_locator);

    participant_ = Domain::createParticipant(PParam);
    if(participant_==nullptr)
        return false;

    partition_name_ = PARTITION_PREFIX + targetAddress;
    return true;
}

ControlParticipant::~ControlParticipant() {
}
