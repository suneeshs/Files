/**
 * @file ControlParticipant.h
 * Subscribes to topic "TargetStatus"
 *
 * Copyright 2019 The MathWorks, Inc.
 */

#ifndef ControlParticipant_H_
#define ControlParticipant_H_

#include "fastrtps/fastrtps_all.h"
#include "../IDL/TargetStatusPubSubTypes.h"
#include "../IDL/TargetControlPubSubTypes.h"
#include "../IDL/ModelStatusPubSubTypes.h"
#include "../IDL/ModelControlPubSubTypes.h"
#include "../IDL/TracingStatusPubSubTypes.h"
#include "../IDL/TracingControlPubSubTypes.h"
#include "../IDL/LoggingStatusPubSubTypes.h"
#include "../IDL/LoggingControlPubSubTypes.h"
#include "../IDL/PTPStatusPubSubTypes.h"
#include "../IDL/PTPControlPubSubTypes.h"
#include "../IDL/SystemLogPubSubTypes.h"
#include "SLRT_RTPS_CONFIG.h"
#include "Participant.h"

namespace slrealtime {
namespace rtps {

class ControlParticipant : public Participant{
  public:
    ControlParticipant();
    ~ControlParticipant();
    bool init(const std::string&);
};


} // namespace rtps
} // namespace slrealtime

#endif /* ControlParticipant_H_ */
