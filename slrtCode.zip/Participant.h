/**
 * @file Participant.h
 * Creates a Participant for use from Model()
 * Participant may be obtained from the model object in order
 * to add new publishers and subscribers using createPublisher
 * and createSubscriber
 *
 * Copyright 2019 The MathWorks, Inc.
 */

#ifndef Participant_H_
#define Participant_H_

#include "fastrtps/fastrtps_all.h"
#include "SLRT_RTPS_CONFIG.h"
#include <typeinfo>

namespace slrealtime {
namespace rtps {

using namespace eprosima::fastrtps;
using namespace eprosima::fastrtps::rtps;

enum class RTPSReliability { BEST_EFFORT, RELIABLE };
enum class RTPSDurability { VOLATILE, TRANSIENT };

////// PUBLISHER //////
template <typename DataT>
class PubListener : public eprosima::fastrtps::PublisherListener {
  public:
    PubListener()
        : n_matched(0){};
    ~PubListener(){};
    void onPublicationMatched(Publisher* pub, eprosima::fastrtps::rtps::MatchingInfo& info);
    bool waitForMatch(std::chrono::seconds timeout);

    std::function<void(bool)> matchedCB_;

  private:
    std::condition_variable waitForMatchCV_;
    std::mutex waitForMatchMutex_;
    int n_matched;
};

template <typename DataT>
bool PubListener<DataT>::waitForMatch(std::chrono::seconds timeout) {
    std::unique_lock<std::mutex> lock(waitForMatchMutex_);
    return waitForMatchCV_.wait_for(lock, timeout, [this] { return (n_matched > 0); });
}

template <typename DataT>
void PubListener<DataT>::onPublicationMatched(eprosima::fastrtps::Publisher* /*pub*/,
                                              eprosima::fastrtps::rtps::MatchingInfo& info) {

    {
        std::lock_guard<std::mutex> lock(waitForMatchMutex_);

        if (info.status == MATCHED_MATCHING) {
            n_matched++;
        } else {
            n_matched--;
        }
    }

    if (matchedCB_) {
        matchedCB_(n_matched > 0);
    }

    waitForMatchCV_.notify_one();
}


template <typename PubSubT, typename DataT>
class ParticipantPublisher {
  public:
    ParticipantPublisher(eprosima::fastrtps::Publisher* publisher)
        : publisher_(publisher)
        , TIMEOUT_DEFAULT(10){};
    ~ParticipantPublisher() {
        publisher_->wait_for_all_acked(eprosima::fastrtps::Time_t(10, 0));
        pubListener_.reset();
        pubSubType_.reset();
        Domain::removePublisher(publisher_);
    };
    bool waitForMatch(std::chrono::seconds timeout) {
        return pubListener_->waitForMatch(timeout);
    }
    bool waitForMatch() {
        return pubListener_->waitForMatch(TIMEOUT_DEFAULT);
    }
    bool publish(DataT*);

    std::unique_ptr<PubListener<DataT>> pubListener_;
    std::unique_ptr<PubSubT> pubSubType_;

  private:
    eprosima::fastrtps::Publisher* publisher_;
    const std::chrono::seconds TIMEOUT_DEFAULT;
};

template <typename PubSubT, typename DataT>
bool ParticipantPublisher<PubSubT, DataT>::publish(DataT* payload) {
    if (publisher_ != nullptr)
        return publisher_->write((void*)payload);
    else
        return false;
}

////// SUBSCRIBER //////
template <typename DataT>
class SubListener : public eprosima::fastrtps::SubscriberListener {
  public:
    SubListener()
        : n_matched(0){};
    ~SubListener(){};
    void onSubscriptionMatched(eprosima::fastrtps::Subscriber* sub,
                               eprosima::fastrtps::rtps::MatchingInfo& info);
    void onNewDataMessage(eprosima::fastrtps::Subscriber* sub);
    bool waitForMatch(std::chrono::seconds timeout);
    bool waitForData(std::chrono::seconds timeout, eprosima::fastrtps::Subscriber* subscriber);

    std::function<void(bool)> matchedCB_;
    std::function<void(DataT&)> dataRcvdCB_;

  private:
    DataT payload_;
    eprosima::fastrtps::SampleInfo_t m_info;

    std::condition_variable waitForMatchCV_;
    std::mutex waitForMatchMutex_;
    int n_matched;

    std::condition_variable waitForDataCV_;
    std::mutex waitForDataMutex_;
};

template <typename DataT>
void SubListener<DataT>::onSubscriptionMatched(Subscriber* /*pub*/, MatchingInfo& info) {
    {
        std::lock_guard<std::mutex> lock(waitForMatchMutex_);
        if (info.status == MATCHED_MATCHING) {
            n_matched++;
        } else {
            n_matched--;
        }
    }
    if (matchedCB_) {
        matchedCB_(n_matched > 0);
    }

    waitForMatchCV_.notify_one();
}

template <typename DataT>
void SubListener<DataT>::onNewDataMessage(Subscriber* sub) {
    if (dataRcvdCB_) {
        // Callback is responsible for handling the received data
        if (sub->takeNextData((void*)&payload_, &m_info)) {
            if (m_info.sampleKind == ALIVE) {
                dataRcvdCB_(payload_);
            }
        }
    } else {
        // waitForData() then takeNextData() will be used
        waitForDataCV_.notify_all();
    }
}

template <typename DataT>
bool SubListener<DataT>::waitForMatch(std::chrono::seconds timeout) {
    std::unique_lock<std::mutex> lock(waitForMatchMutex_);
    return waitForMatchCV_.wait_for(lock, timeout, [this] { return (n_matched > 0); });
}

template <typename DataT>
bool SubListener<DataT>::waitForData(std::chrono::seconds timeout,
                                     eprosima::fastrtps::Subscriber* subscriber) {
    std::unique_lock<std::mutex> lock(waitForDataMutex_);
    return waitForDataCV_.wait_for(lock, timeout,
                                   [subscriber] { return (subscriber->getUnreadCount() > 0); });
}

template <typename PubSubT, typename DataT>
class ParticipantSubscriber {
  public:
    ParticipantSubscriber(eprosima::fastrtps::Subscriber* subscriber)
        : subscriber_(subscriber)
        , TIMEOUT_DEFAULT(10){};

    ~ParticipantSubscriber() {
        try {
            Domain::removeSubscriber(subscriber_);
        } catch (...) {
        }
    };
    bool waitForMatch(std::chrono::seconds timeout) {
        return subListener_->waitForMatch(timeout);
    }
    bool waitForMatch() {
        return subListener_->waitForMatch(TIMEOUT_DEFAULT);
    }
    bool waitForData(std::chrono::seconds timeout) {
        return subListener_->waitForData(timeout, subscriber_);
    }
    bool waitForData() {
        return waitForData(TIMEOUT_DEFAULT);
    }
    bool takeNextData(DataT* data) {
        eprosima::fastrtps::SampleInfo_t m_info;

        if (subscriber_->getUnreadCount() > 0) {

            if (subscriber_->takeNextData((void*)data, &m_info)) {
                if (m_info.sampleKind == ALIVE) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    std::unique_ptr<SubListener<DataT>> subListener_;
    std::unique_ptr<PubSubT> pubSubType_;

  private:
    eprosima::fastrtps::Subscriber* subscriber_;
    const std::chrono::seconds TIMEOUT_DEFAULT;
};

////// PARTICIPANT //////

class Participant {
  public:
    Participant();
    virtual ~Participant();
    virtual bool init(const std::string&) = 0;

    /// @brief Generic method to create publishers associated with a model's
    /// Participant. For an example usage see Model.cpp
    /// Usage: createPublisher<PubSubType, DataType>(
    /// 		DataTypeString, TopicNameString, publisherMatchCallback>())
    /// @tparam PubSubType, DataType are types created from an IDL using fastrtpsgen
    /// @returns Pointer to new ParticipantPublisher<PubSubT, DataT> object
    /// This object will have a publish method
    template <typename PubSubT, typename DataT>
    ParticipantPublisher<PubSubT, DataT>* createPublisher(const std::string,
                                                          const std::string,
                                                          RTPSReliability reliability,
                                                          RTPSDurability,
                                                          std::function<void(bool)>);

    template <typename PubSubT, typename DataT>
    ParticipantPublisher<PubSubT, DataT>* createPublisher(const std::string,
                                                          const std::string,
                                                          RTPSReliability reliability,
                                                          RTPSDurability);

    /// @brief Generic method to create subscribers associated with a model's
    /// Participant. For an example usage see Model.cpp
    /// Usage: createSubscriber<PubSubType, DataType>(
    /// 		DataTypeString, TopicNameString, publisherMatchCallback,
    ///         dataReceivedCallback>())
    /// @tparam PubSubType, DataType are types created from an IDL using fastrtpsgen
    /// @returns Pointer to new ParticipantSubscriber<PubSubT, DataT> object
    template <typename PubSubT, typename DataT>
    ParticipantSubscriber<PubSubT, DataT>* createSubscriber(const std::string,
                                                            const std::string,
                                                            RTPSReliability reliability,
                                                            RTPSDurability durability,
                                                            std::function<void(bool)>,
                                                            std::function<void(DataT&)>);

    template <typename PubSubT, typename DataT>
    ParticipantSubscriber<PubSubT, DataT>* createSubscriber(const std::string,
                                                            const std::string,
                                                            RTPSReliability reliability,
                                                            RTPSDurability durability);

  protected:
    eprosima::fastrtps::Participant* participant_;
    std::string partition_name_;
};

// Generic methods to create publisher
template <typename PubSubT, typename DataT>
ParticipantPublisher<PubSubT, DataT>* Participant::createPublisher(
    const std::string dataTypeName,
    const std::string topicName,
    RTPSReliability reliability,
    RTPSDurability durability,
    std::function<void(bool)> pubMatchedCB) {
    
    std::unique_ptr<PubSubT> pubSubType(new PubSubT());
    // Register the type if it is not yet registered
    eprosima::fastrtps::TopicDataType* regType[1];
    if (!Domain::getRegisteredType(participant_, dataTypeName.c_str(), regType))
        Domain::registerType(participant_, pubSubType.get());

    std::unique_ptr<PubListener<DataT>> pubListener(new PubListener<DataT>());
    if (pubMatchedCB)
         pubListener->matchedCB_ = pubMatchedCB;

    PublisherAttributes publisherAttr;
    publisherAttr.topic.topicDataType = dataTypeName;
    publisherAttr.topic.topicName = topicName;

    switch (reliability) {
    case RTPSReliability::BEST_EFFORT:
        publisherAttr.qos.m_reliability.kind = BEST_EFFORT_RELIABILITY_QOS;
        break;
    case RTPSReliability::RELIABLE:
        publisherAttr.qos.m_reliability.kind = RELIABLE_RELIABILITY_QOS;
        break;
    }

    switch (durability) {
    case RTPSDurability::VOLATILE:
        publisherAttr.qos.m_durability.kind = VOLATILE_DURABILITY_QOS;
    case RTPSDurability::TRANSIENT:
        publisherAttr.qos.m_durability.kind = TRANSIENT_LOCAL_DURABILITY_QOS;
    }

    publisherAttr.qos.m_partition.push_back(partition_name_.c_str());
    eprosima::fastrtps::Publisher* publisher =
        Domain::createPublisher(participant_, publisherAttr, (PublisherListener*)pubListener.get());
    if (publisher == nullptr) {
        throw std::runtime_error("Error creating publisher");
    } else {
        ParticipantPublisher<PubSubT, DataT>* pub =
            new ParticipantPublisher<PubSubT, DataT>(publisher);
        pub->pubListener_ = std::move(pubListener);
        pub->pubSubType_ = std::move(pubSubType);
        return pub;
    }
}

template <typename PubSubT, typename DataT>
        ParticipantPublisher<PubSubT, DataT>* Participant::createPublisher(const std::string dataTypeName,
        const std::string topicName,
        RTPSReliability reliability,
        RTPSDurability durability) {
    
    return createPublisher<PubSubT, DataT>(dataTypeName, topicName, reliability, durability,
            std::function<void(bool)> ());
}

// Generic methods to create subscriber
template <typename PubSubT, typename DataT>
        ParticipantSubscriber<PubSubT, DataT>* Participant::createSubscriber(
        const std::string dataTypeName,
        const std::string topicName,
        RTPSReliability reliability,
        RTPSDurability durability,
        std::function<void(bool)> subMatchedCB,
        std::function<void(DataT&)> dataRcvdCB) {
    
    std::unique_ptr<PubSubT> pubSubType(new PubSubT());
    // Register the type if it is not yet registered
    eprosima::fastrtps::TopicDataType* regType[1];
    if (!Domain::getRegisteredType(participant_, dataTypeName.c_str(), regType))
        Domain::registerType(participant_, pubSubType.get());
    
    std::unique_ptr<SubListener<DataT>> subListener(new SubListener<DataT>());
    if (subMatchedCB)
        subListener->matchedCB_ = subMatchedCB;
    if (dataRcvdCB)
        subListener->dataRcvdCB_ = dataRcvdCB;
    
    SubscriberAttributes subscriberAttr;
    subscriberAttr.topic.topicDataType = dataTypeName;
    subscriberAttr.topic.topicName = topicName;
    
    switch (reliability) {
        case RTPSReliability::BEST_EFFORT:
            subscriberAttr.qos.m_reliability.kind = BEST_EFFORT_RELIABILITY_QOS;
            break;
        case RTPSReliability::RELIABLE:
            subscriberAttr.qos.m_reliability.kind = RELIABLE_RELIABILITY_QOS;
            break;
    }
    
    switch (durability) {
        case RTPSDurability::VOLATILE:
            subscriberAttr.qos.m_durability.kind = VOLATILE_DURABILITY_QOS;
            break;
        case RTPSDurability::TRANSIENT:
            subscriberAttr.qos.m_durability.kind = TRANSIENT_LOCAL_DURABILITY_QOS;
            break;
    }
    
    subscriberAttr.qos.m_partition.push_back(partition_name_.c_str());
    eprosima::fastrtps::Subscriber* subscriber = Domain::createSubscriber(
            participant_, subscriberAttr, (SubscriberListener*)subListener.get());
    if (subscriber == nullptr) {
        throw std::runtime_error("Error creating subscriber");
    } else {
        ParticipantSubscriber<PubSubT, DataT>* sub =
                new ParticipantSubscriber<PubSubT, DataT>(subscriber);
        sub->subListener_ = std::move(subListener);
        sub->pubSubType_ = std::move(pubSubType);
        return sub;
    }
}

template <typename PubSubT, typename DataT>
        ParticipantSubscriber<PubSubT, DataT>* Participant::createSubscriber(const std::string dataTypeName,
        const std::string topicName,
        RTPSReliability reliability,
        RTPSDurability durability) {
    
    return createSubscriber<PubSubT, DataT>(dataTypeName, topicName, reliability, durability,
            std::function<void(bool)> (), std::function<void(DataT&)> () );
}

} // namespace rtps
} // namespace slrealtime

#endif /* Participant_H_ */

/* LocalWords:  rtps slrealtime
 */
